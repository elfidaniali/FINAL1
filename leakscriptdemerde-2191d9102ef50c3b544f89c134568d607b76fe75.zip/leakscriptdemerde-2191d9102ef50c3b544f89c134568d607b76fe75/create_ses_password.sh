#!/bin/bash
curl -s https://gist.githubusercontent.com/memiah-steve/593c2026782309367f1e1edfef07f9af/raw/9da354319028562fda1cd6954bc8cbb345e0810d/aws-ses-smtp-password.sh | sh -s -- $1

